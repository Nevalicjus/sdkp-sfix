public class Main {
    public static void main(String[] args) {
        //SDKPSubmissionFixer.fixSubmission("tpo1_kj_s12345.zip");
        SDKPSubmissionFixer.fixSubmission(
            new SDKPSubmissionFixer.SubmissionFile("UTP", 1, "Jan", "Kowalski", "s12345"),
            "tpo1_kj_s12345.zip"
        );
    }
}
